// Exercise 2:
// Read provided csv file and find create the log of issues find in the file:
// 1. Find the records where symbol name not end with '.NSE'
// 2. Find the records where Open value is 0(Zero).
// 3. Find the records where Volume value is decimal.

// Create csv file with above records which has errors in it.

const express = require('express');
const app = express();
const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

app.get('/find-issues', (req, res) => {
    let invalidSymbols = [];
    let invalidOpenValues = [];
    let invalidVolumeValues = [];
    fs.createReadStream('Sample_13122022.csv')
        .pipe(csv())
        .on('data', (data) => {
            if (!data.Symbol.endsWith('.NSE')) {
                invalidSymbols.push(data);
            }
            if (data.Open === 0) {
                invalidOpenValues.push(data);
            }
            if (!Number.isInteger(data.Volume)) {
                invalidVolumeValues.push(data);
            }
        })
        .on('end', () => {
            const csvWriter = createCsvWriter({
                path: 'Sample_13122022.csv',
                header: [
                    { id: 'Symbol', title: 'Symbol' },
                    { id: 'Open', title: 'Open' },
                    { id: 'Volume', title: 'Volume' },
                ]
            });
            csvWriter
                .writeRecords([...invalidSymbols, ...invalidOpenValues, ...invalidVolumeValues])
                .then(() => {
                    console.log('Invalid data written to file successfully');
                });
        });
});

app.get('/download', function(req, res){
    let  file = __dirname + '/Sample_13122022.csv';
    res.download(file);
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on PORT ${PORT}`);
});